import React, { useState } from 'react';
import { motion } from 'framer-motion';

const Newsletter = () => {
  const [email, setEmail] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle newsletter signup
    setEmail('');
  };

  return (
    <section className="section-padding bg-warm-gray-100">
      <div className="max-w-4xl mx-auto text-center container-padding">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="font-serif text-3xl md:text-4xl mb-4">Join Our Inner Circle</h2>
          <p className="text-warm-gray-600 mb-8">
            Subscribe to receive exclusive offers, early access to new collections, and €100 off your first purchase over €1000.
          </p>
          <form onSubmit={handleSubmit} className="max-w-md mx-auto">
            <div className="flex gap-4">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email"
                className="flex-1 px-4 py-3 border border-warm-gray-300 focus:outline-none focus:border-gold"
                required
              />
              <button type="submit" className="btn-primary whitespace-nowrap">
                Subscribe
              </button>
            </div>
          </form>
        </motion.div>
      </div>
    </section>
  );
};

export default Newsletter;