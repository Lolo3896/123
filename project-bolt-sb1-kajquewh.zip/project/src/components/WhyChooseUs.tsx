import React from 'react';
import { motion } from 'framer-motion';
import { Diamond, Award, Gem } from 'lucide-react';

const features = [
  {
    icon: Diamond,
    title: "Exceptional Craftsmanship",
    description: "Each piece is meticulously handcrafted by master artisans with decades of experience."
  },
  {
    icon: Award,
    title: "Certified Quality",
    description: "All our gemstones are ethically sourced and certified by international gemological institutes."
  },
  {
    icon: Gem,
    title: "Bespoke Service",
    description: "Experience our personalized design service to create your perfect piece of jewelry."
  }
];

const WhyChooseUs = () => {
  return (
    <section className="section-padding bg-white">
      <div className="max-w-7xl mx-auto container-padding">
        <motion.h2 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="font-serif text-3xl md:text-4xl text-center mb-16"
        >
          Why Choose Us
        </motion.h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              viewport={{ once: true }}
              className="text-center"
            >
              <div className="mb-6 flex justify-center">
                <feature.icon className="w-12 h-12 text-gold" strokeWidth={1.5} />
              </div>
              <h3 className="font-serif text-xl mb-3">{feature.title}</h3>
              <p className="text-warm-gray-600 leading-relaxed">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WhyChooseUs;