import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X, Search, ShoppingBag, Heart } from 'lucide-react';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="fixed w-full bg-white/95 backdrop-blur-sm z-50 shadow-sm">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between items-center h-20">
          {/* Logo */}
          <Link to="/" className="font-serif text-2xl tracking-wider">LUXE</Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex space-x-8">
            <Link to="/collections" className="hover:text-gold transition-colors">Collections</Link>
            <Link to="/jewelry" className="hover:text-gold transition-colors">Jewelry</Link>
            <Link to="/about" className="hover:text-gold transition-colors">About</Link>
            <Link to="/services" className="hover:text-gold transition-colors">Services</Link>
          </div>

          {/* Icons */}
          <div className="hidden md:flex items-center space-x-6">
            <Search className="w-5 h-5 cursor-pointer hover:text-gold transition-colors" />
            <Heart className="w-5 h-5 cursor-pointer hover:text-gold transition-colors" />
            <ShoppingBag className="w-5 h-5 cursor-pointer hover:text-gold transition-colors" />
          </div>

          {/* Mobile Menu Button */}
          <button className="md:hidden" onClick={() => setIsOpen(!isOpen)}>
            {isOpen ? <X /> : <Menu />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-white">
          <div className="px-4 pt-2 pb-6 space-y-4">
            <Link to="/collections" className="block py-2 hover:text-gold transition-colors">Collections</Link>
            <Link to="/jewelry" className="block py-2 hover:text-gold transition-colors">Jewelry</Link>
            <Link to="/about" className="block py-2 hover:text-gold transition-colors">About</Link>
            <Link to="/services" className="block py-2 hover:text-gold transition-colors">Services</Link>
            <div className="flex space-x-6 pt-4">
              <Search className="w-5 h-5" />
              <Heart className="w-5 h-5" />
              <ShoppingBag className="w-5 h-5" />
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;