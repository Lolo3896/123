import React from 'react';
import { Link } from 'react-router-dom';

const categories = [
  {
    title: 'Rings',
    image: 'https://images.unsplash.com/photo-1605100804763-247f67b3557e?auto=format&fit=crop&q=80',
    link: '/collections/rings'
  },
  {
    title: 'Necklaces',
    image: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&q=80',
    link: '/collections/necklaces'
  },
  {
    title: 'Earrings',
    image: 'https://images.unsplash.com/photo-1617038220319-276d3cfab638?auto=format&fit=crop&q=80',
    link: '/collections/earrings'
  }
];

const FeaturedCategories = () => {
  return (
    <section className="section-padding bg-cream">
      <div className="max-w-7xl mx-auto container-padding">
        <h2 className="font-serif text-3xl md:text-4xl text-center mb-12">Curated Collections</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {categories.map((category) => (
            <Link 
              to={category.link} 
              key={category.title}
              className="group relative overflow-hidden"
            >
              <div className="aspect-square overflow-hidden">
                <img
                  src={category.image}
                  alt={category.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
              </div>
              <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
                <h3 className="text-white font-serif text-2xl">{category.title}</h3>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturedCategories;