import React from 'react';
import { motion } from 'framer-motion';

const Hero = () => {
  return (
    <div className="relative h-screen">
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?auto=format&fit=crop&q=80"
          alt="Luxury jewelry collection"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/30" />
      </div>
      
      <div className="relative h-full flex items-center justify-center text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-white max-w-3xl px-4"
        >
          <h1 className="font-serif text-4xl md:text-6xl lg:text-7xl mb-6">
            Timeless Elegance, Modern Spirit
          </h1>
          <p className="text-lg md:text-xl mb-8 font-light">
            Discover our signature collection of handcrafted jewelry, where tradition meets contemporary design
          </p>
          <button className="btn-primary">
            Explore Collection
          </button>
        </motion.div>
      </div>
    </div>
  );
};

export default Hero;