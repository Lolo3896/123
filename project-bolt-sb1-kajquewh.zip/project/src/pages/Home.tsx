import React from 'react';
import Hero from '../components/Hero';
import FeaturedCategories from '../components/FeaturedCategories';
import WhyChooseUs from '../components/WhyChooseUs';
import Newsletter from '../components/Newsletter';

const Home = () => {
  return (
    <main>
      <Hero />
      <WhyChooseUs />
      <FeaturedCategories />
      <Newsletter />
    </main>
  );
};

export default Home;