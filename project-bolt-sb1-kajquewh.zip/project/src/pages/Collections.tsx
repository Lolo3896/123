import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

const collections = [
  {
    category: "Rings",
    items: [
      {
        name: "Diamond Solitaire Ring",
        price: "€5,200",
        image: "https://images.unsplash.com/photo-1605100804763-247f67b3557e?auto=format&fit=crop&q=80"
      },
      {
        name: "Sapphire Halo Ring",
        price: "€3,800",
        image: "https://images.unsplash.com/photo-1603561591411-07134e71a2a9?auto=format&fit=crop&q=80"
      },
      {
        name: "Emerald Cut Diamond Ring",
        price: "€7,500",
        image: "https://images.unsplash.com/photo-1608042314453-ae338d80c427?auto=format&fit=crop&q=80"
      }
    ]
  },
  {
    category: "Necklaces",
    items: [
      {
        name: "Diamond Pendant Necklace",
        price: "€2,800",
        image: "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&q=80"
      },
      {
        name: "Pearl Strand Necklace",
        price: "€1,900",
        image: "https://images.unsplash.com/photo-1611085583191-a3b181a88401?auto=format&fit=crop&q=80"
      },
      {
        name: "Gold Chain Necklace",
        price: "€3,200",
        image: "https://images.unsplash.com/photo-1602173574767-37ac01994b2a?auto=format&fit=crop&q=80"
      }
    ]
  },
  {
    category: "Earrings",
    items: [
      {
        name: "Pearl Drop Earrings",
        price: "€1,500",
        image: "https://images.unsplash.com/photo-1617038220319-276d3cfab638?auto=format&fit=crop&q=80"
      },
      {
        name: "Diamond Stud Earrings",
        price: "€4,200",
        image: "https://images.unsplash.com/photo-1596944924616-7b38e7cfac36?auto=format&fit=crop&q=80"
      },
      {
        name: "Gold Hoop Earrings",
        price: "€980",
        image: "https://images.unsplash.com/photo-1635767798638-3e25273a8236?auto=format&fit=crop&q=80"
      }
    ]
  }
];

const Collections = () => {
  return (
    <div className="pt-20 min-h-screen bg-white">
      <div className="max-w-7xl mx-auto px-4 py-16 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h1 className="font-serif text-4xl md:text-5xl mb-4">Our Collections</h1>
          <p className="text-warm-gray-600 max-w-2xl mx-auto">
            Discover our carefully curated collection of fine jewelry, each piece crafted with exceptional attention to detail and timeless elegance.
          </p>
        </motion.div>

        {collections.map((collection, index) => (
          <motion.section
            key={collection.category}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: index * 0.2 }}
            viewport={{ once: true }}
            className="mb-20"
          >
            <h2 className="font-serif text-3xl mb-8 text-center">{collection.category}</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {collection.items.map((item) => (
                <Link
                  key={item.name}
                  to={`/product/${item.name.toLowerCase().replace(/\s+/g, '-')}`}
                  className="group"
                >
                  <div className="relative aspect-square overflow-hidden bg-warm-gray-100">
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                    />
                  </div>
                  <div className="mt-4 text-center">
                    <h3 className="font-serif text-lg mb-1">{item.name}</h3>
                    <p className="text-warm-gray-600">{item.price}</p>
                  </div>
                </Link>
              ))}
            </div>
          </motion.section>
        ))}
      </div>
    </div>
  );
};

export default Collections;